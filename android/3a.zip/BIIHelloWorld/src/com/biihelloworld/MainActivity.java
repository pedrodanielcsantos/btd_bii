package com.biihelloworld;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

	Button sayHelloButton;
	TextView helloTextView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		Log.i("TAG", "OnCreate");
		
		sayHelloButton = (Button) findViewById(R.id.sayHelloButton);
		helloTextView = (TextView) findViewById(R.id.helloTextView);
		
		sayHelloButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(helloTextView.getText().toString().equals(getResources().getString(R.string.hello_world))){
					helloTextView.setText("");
					sayHelloButton.setText(getResources().getString(R.string.sayHello));
				}else{
					helloTextView.setText(getResources().getString(R.string.hello_world));
					sayHelloButton.setText(getResources().getString(R.string.hideHello));
				}
			}
		});
		
		Log.i("TAG","Assigned all the variables...");
	}
}
