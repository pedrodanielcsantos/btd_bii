//Enum to control the game state.
public enum GameState{
 START, READY, BLUEONLY, REDONLY, NOHURDLES, BOTH, END
};
