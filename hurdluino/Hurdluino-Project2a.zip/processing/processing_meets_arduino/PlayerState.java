//Enum to control each player's state.
public enum PlayerState{
 SET, RUNNING, JUMPING, HURTING ,FALLING
};
